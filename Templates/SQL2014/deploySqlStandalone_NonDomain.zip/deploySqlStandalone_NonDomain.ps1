#
# Copyright="?Microsoft Corporation. All rights reserved."
#

configuration deploySqlStandalone
{
    param
    ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLServicecreds,

	[string]$sqlInstallationISOUri = "http://care.dlservice.microsoft.com/dl/download/2/F/8/2F8F7165-BB21-4D1E-B5D8-3BD3CE73C77D/SQLServer2014SP1-FullSlipstream-x64-ENU.iso",
		
        [UInt32]$DatabaseEnginePort = 1433       
    )

    Import-DscResource -ModuleName xComputerManagement,CDisk,xActiveDirectory,XDisk,xSql, xSQLServer, xSQLps,xNetworking, xDeploy, xDownloadISO
	Import-DscResource -ModuleName xDownloadFile
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$SQLCreds = New-Object System.Management.Automation.PSCredential ("$($SQLServicecreds.UserName)", $SQLServicecreds.Password)

	$downloadPath = Join-Path $env:SystemDrive "MSI"
    Node localhost
    { 
        xDownloadISO DownloadSQL
        {
            SourcePath = $sqlInstallationISOUri
            DestinationDirectoryPath = "C:\SQL2014"
        }
        File SQLUpdatesFolder
        {
            Ensure = "Present"
            Type = "Directory"
            DestinationPath = "C:\SQL2014\Updates"
            DependsOn = '[xDownloadISO]DownloadSQL'
        } 
        WindowsFeature installdotNet35 
        {             
            Ensure = "Present"
            Name = "Net-Framework-Core"
            DependsOn = '[File]SQLUpdatesFolder'
        }
        xSqlServerSetup InstallSqlServer
        {
            InstanceName =  "MSSQLSERVER"
            SourcePath = "C:"
            SourceFolder = "\SQL2014"
            UpdateSource = ".\Updates"
            UpdateEnabled = "False"
            SQLSysAdminAccounts = $DomainCreds.username
            Credential = $DomainCreds
            Features= "SQLENGINE,SSMS"
            SecurityMode="SQL"
            SAPwd=$SQLCreds
            SQLUserDBDir = "c:\SQL\Data"
            SQLUserDBLogDir = "c:\SQL\Log"
            DependsOn = '[WindowsFeature]installdotNet35'
        }

        xFirewall DatabaseEngineFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Database-Engine-TCP-In"
            DisplayName = "SQL Server Database Engine (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Engine."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = $DatabaseEnginePort -as [String]
            Ensure = "Present"
            DependsOn = '[xSqlServerSetup]InstallSqlServer'
        }

        xFirewall DatabaseMirroringFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Database-Mirroring-TCP-In"
            DisplayName = "SQL Server Database Mirroring (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Mirroring."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "5022"
            Ensure = "Present"
            DependsOn = '[xFirewall]DatabaseEngineFirewallRule'
        }

        xFirewall ListenerFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Availability-Group-Listener-TCP-In"
            DisplayName = "SQL Server Availability Group Listener (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Availability Group listener."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "59999"
            Ensure = "Present"
            DependsOn = '[xFirewall]DatabaseMirroringFirewallRule'
        }
 
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $True
        }

    }
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

function WaitForSqlSetup
{
    # Wait for SQL Server Setup to finish before proceeding.
    while ($true)
    {
        try
        {
            Get-ScheduledTaskInfo "\ConfigureSqlImageTasks\RunConfigureImage" -ErrorAction Stop
            Start-Sleep -Seconds 5
        }
        catch
        {
            break
        }
    }
}
